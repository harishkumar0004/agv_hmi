"""
setting_button.py

Reusable Settings button for the AGV HMI.
Uses QSvgWidget for crisp SVG rendering.
"""

from pathlib import Path

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtSvgWidgets import QSvgWidget
from PyQt6.QtWidgets import (
    QApplication,
    QPushButton,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
)

# --------------------------------------------------------
# Assets
# --------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent.parent
ASSETS_DIR = PROJECT_ROOT / "assets"

SETTINGS_ICON = ASSETS_DIR / "setting.svg"


class SettingsButton(QPushButton):

    clicked_signal = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setup_ui()
        self.setup_connections()

    def setup_ui(self):

        self.setFixedSize(44, 44)

        self.setCursor(Qt.CursorShape.PointingHandCursor)

        self.setFlat(True)

        self.setStyleSheet("""
            QPushButton{
                border:none;
                background:transparent;
                border-radius:22px;
            }

            QPushButton:hover{
                background:#2F343F;
            }

            QPushButton:pressed{
                background:#444B58;
            }
        """)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        if SETTINGS_ICON.exists():

            print(f"[INFO] SVG Found : {SETTINGS_ICON}")

            self.icon_widget = QSvgWidget(str(SETTINGS_ICON))
            self.icon_widget.setFixedSize(24, 24)

            layout.addWidget(self.icon_widget)

        else:

            print(f"[ERROR] SVG Not Found : {SETTINGS_ICON}")

    def setup_connections(self):

        self.clicked.connect(self.clicked_signal.emit)


# --------------------------------------------------------
# Standalone Test
# --------------------------------------------------------

if __name__ == "__main__":

    import sys

    app = QApplication(sys.argv)      # MUST be first

    window = QWidget()
    window.setWindowTitle("Settings Button Test")

    window.setStyleSheet("""
        background:white;
    """)

    layout = QVBoxLayout(window)
    layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

    button = SettingsButton()

    button.clicked_signal.connect(
        lambda: print("Settings button clicked.")
    )

    layout.addWidget(button)

    window.resize(250,180)

    window.show()

    sys.exit(app.exec())