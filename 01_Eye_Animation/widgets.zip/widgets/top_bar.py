from PyQt6.QtCore import Qt, QTimer, QTime
from PyQt6.QtWidgets import (QWidgets, QPushButton, QLabel, QHBoxLayout,)

class TopBar(QWidget):
    def __init__(self):
        super().__init__()

        self.setup_ui()
        self.setup_timer()

    def setup_ai(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(15, 10, 15, 10)
        layout.setSpacing(20)

        

    def setup_timer(self):
